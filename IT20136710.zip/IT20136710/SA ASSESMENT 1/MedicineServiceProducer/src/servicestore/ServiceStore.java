package servicestore;

import java.util.ArrayList;
import java.util.List;

import model.Service;


public class ServiceStore {
	
	//STORE SHARED DATA AMOUNG PRODUCER AND CONSUMER
	public static List<Service> serviceList = new ArrayList<Service>();
	//public static List<Service1> serviceList1 = new ArrayList<Service1>();
}